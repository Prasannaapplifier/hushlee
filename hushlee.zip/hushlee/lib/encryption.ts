import crypto from 'crypto';
import { prisma } from './db';
import { recordAuditLog } from './audit';

/**
 * Hushlee Field-Level Envelope Encryption Service
 * 
 * Cryptographic Architecture:
 * 1. Master Key (KEK - Key Encryption Key):
 *    - 256-bit AES key loaded from ENCRYPTION_MASTER_KEY environment variable.
 *    - Never stored in the database.
 * 2. Per-User Data Encryption Key (DEK):
 *    - 256-bit cryptographically secure random key generated per user.
 *    - Stored encrypted in `users.encrypted_dek` using AES-256-GCM with the Master KEK.
 * 3. Message Content:
 *    - Encrypted at rest in `messages.content_encrypted` using the user's decrypted DEK with AES-256-GCM.
 *    - Raw message plaintext is NEVER persisted in PostgreSQL.
 */

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12; // 96 bits for AES-GCM
const KEY_LENGTH = 32; // 256 bits

export interface VersionedEncryptedPayload {
  v: number;          // Format version (1)
  alg: string;        // 'aes-256-gcm'
  iv: string;         // Base64
  authTag: string;    // Base64
  ciphertext: string; // Base64
}

/**
 * Resolves the 256-bit master key from environment variables.
 */
export function getMasterKey(): Buffer {
  const masterKeyHex = process.env.ENCRYPTION_MASTER_KEY;
  if (!masterKeyHex) {
    console.warn('[Hushlee Crypto] ENCRYPTION_MASTER_KEY not set. Using derived development fallback key.');
    return crypto.scryptSync('hushlee-default-dev-master-key-32b', 'salt-2026', KEY_LENGTH);
  }

  const keyBuf = Buffer.from(masterKeyHex, 'hex');
  if (keyBuf.length !== KEY_LENGTH) {
    throw new Error(`ENCRYPTION_MASTER_KEY must be exactly 32 bytes (64 hex characters). Got ${keyBuf.length} bytes.`);
  }
  return keyBuf;
}

/**
 * Encrypt a plaintext buffer or string with an AES-256 key.
 */
export function encryptWithKey(plainData: Buffer | string, key: Buffer): VersionedEncryptedPayload {
  const dataBuffer = Buffer.isBuffer(plainData) ? plainData : Buffer.from(plainData, 'utf8');
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);

  const encryptedBuffer = Buffer.concat([cipher.update(dataBuffer), cipher.final()]);
  const authTag = cipher.getAuthTag();

  return {
    v: 1,
    alg: ALGORITHM,
    iv: iv.toString('base64'),
    authTag: authTag.toString('base64'),
    ciphertext: encryptedBuffer.toString('base64'),
  };
}

/**
 * Decrypt a VersionedEncryptedPayload using an AES-256 key.
 */
export function decryptWithKey(payload: VersionedEncryptedPayload, key: Buffer): Buffer {
  if (payload.v !== 1) {
    throw new Error(`Unsupported encryption payload version: ${payload.v}`);
  }

  const iv = Buffer.from(payload.iv, 'base64');
  const authTag = Buffer.from(payload.authTag, 'base64');
  const ciphertext = Buffer.from(payload.ciphertext, 'base64');

  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(authTag);

  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

/**
 * Retrieves the user's decrypted DEK.
 * If the user has no DEK yet, generates a new 256-bit DEK, encrypts it with the Master Key,
 * and saves it in `users.encrypted_dek`.
 */
export async function getOrCreateUserDek(userId: string): Promise<Buffer> {
  const masterKey = getMasterKey();

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, encryptedDek: true },
  });

  if (!user) {
    throw new Error(`User not found: ${userId}`);
  }

  if (user.encryptedDek) {
    try {
      const payload: VersionedEncryptedPayload = JSON.parse(user.encryptedDek);
      return decryptWithKey(payload, masterKey);
    } catch (err) {
      console.error(`Failed to decrypt DEK for user ${userId}, generating fresh key:`, err);
    }
  }

  // Generate brand new 256-bit random key
  const freshDek = crypto.randomBytes(KEY_LENGTH);
  const encryptedPayload = encryptWithKey(freshDek, masterKey);

  await prisma.user.update({
    where: { id: userId },
    data: {
      encryptedDek: JSON.stringify(encryptedPayload),
    },
  });

  return freshDek;
}

/**
 * Encrypts message content with the user's DEK.
 * Stored in `messages.content_encrypted`.
 */
export async function encryptUserMessage(userId: string, plaintext: string): Promise<string> {
  const userDek = await getOrCreateUserDek(userId);
  const payload = encryptWithKey(plaintext, userDek);
  return JSON.stringify(payload);
}

/**
 * Decrypts message content with the user's DEK.
 */
export async function decryptUserMessage(userId: string, serializedPayload: string): Promise<string> {
  const userDek = await getOrCreateUserDek(userId);
  const payload: VersionedEncryptedPayload = JSON.parse(serializedPayload);
  const decryptedBuf = decryptWithKey(payload, userDek);
  return decryptedBuf.toString('utf8');
}

/**
 * Privileged admin decryption access.
 * As mandated by SPEC.md Section 5:
 * "Even admins/support staff should not be able to read raw messages without a logged, justified access event."
 */
export async function adminDecryptMessage(
  adminId: string,
  userId: string,
  messageId: string,
  reason: string,
  serializedPayload: string
): Promise<string> {
  if (!reason || reason.trim().length < 10) {
    throw new Error('A detailed justification reason is required for privileged message access.');
  }

  // 1. Mandatory audit log write BEFORE releasing decrypted content
  await recordAuditLog({
    userId,
    actor: 'admin',
    action: 'admin_access',
    metadata: {
      adminId,
      messageId,
      reason,
      accessedAt: new Date().toISOString(),
    },
  });

  // 2. Perform decryption
  return await decryptUserMessage(userId, serializedPayload);
}
