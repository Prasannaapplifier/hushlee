/**
 * Hushlee Safety & Escalation Classifier
 * 
 * Evaluates messages server-side for:
 * 1. 'self_harm': Suicidal ideation, intent, or self-inflicted injury.
 * 2. 'abuse_disclosure': Intimate partner violence, coercive control, physical/sexual assault, threats.
 * 3. 'crisis': Acute overwhelming panic, severe disassociation, urgent danger.
 * 
 * As specified in SPEC.md Section 6:
 * - Runs on every user message server-side before/alongside the Claude call.
 * - Flags are logged to `safety_flags` for audit and care escalation.
 * - Detection is handled gracefully: never exposes an invasive "surveillance" warning to the user.
 */

export interface SafetyCheckResult {
  flagged: boolean;
  category?: 'self_harm' | 'abuse_disclosure' | 'crisis';
  severity?: 'high' | 'medium';
  reason?: string;
}

// 1. Self-Harm & Suicide Indicators
const SELF_HARM_PATTERNS = [
  /\b(kill myself|killing myself|suicid(e|al)|want to die|wanna die|end my life|ending it all)\b/i,
  /\b(take my own life|better off dead|wish i was dead|wish i were dead|no reason to live)\b/i,
  /\b(hang myself|slit my (wrists|throat)|overdose|cut myself|cutting myself|hurt myself intentionally)\b/i,
  /\b(can'?t go on living|goodbye everyone|don'?t want to wake up)\b/i,
  /\b(planning to die|giving away my things|swallowed a bunch of pills)\b/i,
];

// 2. Domestic Violence & Abuse Disclosure Indicators
const ABUSE_PATTERNS = [
  /\b(hits? me|hitting me|beat(s|ing)? me|punched me|slapped me|kicked me|choked me|choking me)\b/i,
  /\b(physically (abused|hurts|hurt me)|bruised me|broke my (arm|finger|nose|rib))\b/i,
  /\b(threatened to (kill|shoot|stab|harm|burn) me|threatens to kill me)\b/i,
  /\b(forced me to have sex|sexual(ly)? assaulted|raped me|coerced me into sex)\b/i,
  /\b(locked me in (the room|the house|a closet)|won'?t let me leave the house|took my passport)\b/i,
  /\b(afraid (he|she|they) (will|might) kill me|scared for my physical life|afraid for my life)\b/i,
  /\b(holds a (gun|knife) to me|threatening me with a (gun|knife))\b/i,
];

// 3. Acute Crisis / Extreme Emergency Indicators
const CRISIS_PATTERNS = [
  /\b(in immediate danger|someone is breaking in|he is outside with a weapon|she has a gun)\b/i,
  /\b(bleeding out|having a heart attack|can'?t breathe and passed out)\b/i,
  /\b(acute psychosis|voices telling me to hurt)\b/i,
];

export async function evaluateSafety(content: string): Promise<SafetyCheckResult> {
  const normalized = content.trim().toLowerCase();

  // 1. Check for immediate Self-Harm signals
  for (const pattern of SELF_HARM_PATTERNS) {
    if (pattern.test(normalized)) {
      return {
        flagged: true,
        category: 'self_harm',
        severity: 'high',
        reason: 'Detected self-harm or suicidal ideation phrase',
      };
    }
  }

  // 2. Check for Abuse / Domestic Violence disclosure
  for (const pattern of ABUSE_PATTERNS) {
    if (pattern.test(normalized)) {
      return {
        flagged: true,
        category: 'abuse_disclosure',
        severity: 'high',
        reason: 'Detected intimate partner violence or abuse disclosure',
      };
    }
  }

  // 3. Check for Acute Crisis
  for (const pattern of CRISIS_PATTERNS) {
    if (pattern.test(normalized)) {
      return {
        flagged: true,
        category: 'crisis',
        severity: 'high',
        reason: 'Detected urgent physical danger or crisis',
      };
    }
  }

  return { flagged: false };
}
