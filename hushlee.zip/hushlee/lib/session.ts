import { auth } from '@/auth';
import { prisma } from './db';
import { cookies } from 'next/headers';

export interface UserSessionData {
  id: string;
  email?: string | null;
  consentBackupAckAt?: Date | null;
  isGuest?: boolean;
}

const GUEST_COOKIE_NAME = 'hushlee_guest_user_id';

/**
 * Resolves current user either from Auth.js session or persistent guest session.
 * This guarantees zero friction for testing and onboarding while enforcing the consent requirement.
 */
export async function getCurrentUser(): Promise<UserSessionData> {
  const session = await auth();

  if (session?.user?.id) {
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { id: true, email: true, consentBackupAckAt: true },
    });

    if (user) {
      return {
        id: user.id,
        email: user.email,
        consentBackupAckAt: user.consentBackupAckAt,
        isGuest: false,
      };
    }
  }

  // Check or establish guest cookie
  const cookieStore = await cookies();
  let guestId = cookieStore.get(GUEST_COOKIE_NAME)?.value;

  if (guestId) {
    const guestUser = await prisma.user.findUnique({
      where: { id: guestId },
      select: { id: true, email: true, consentBackupAckAt: true },
    });

    if (guestUser) {
      return {
        id: guestUser.id,
        email: guestUser.email,
        consentBackupAckAt: guestUser.consentBackupAckAt,
        isGuest: true,
      };
    }
  }

  // Create new guest user
  const newGuest = await prisma.user.create({
    data: {},
    select: { id: true, email: true, consentBackupAckAt: true },
  });

  try {
    cookieStore.set(GUEST_COOKIE_NAME, newGuest.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 90, // 90 days matching retention policy
      path: '/',
    });
  } catch {
    // Some contexts (read-only) might not allow setting cookie
  }

  return {
    id: newGuest.id,
    email: newGuest.email,
    consentBackupAckAt: newGuest.consentBackupAckAt,
    isGuest: true,
  };
}
