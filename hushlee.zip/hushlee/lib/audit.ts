import { prisma } from './db';
import { Prisma } from '@prisma/client';

export type AuditActor = 'user' | 'system' | 'admin';
export type AuditAction =
  | 'message_sent'
  | 'export_requested'
  | 'admin_access'
  | 'deletion_requested'
  | 'consent_given'
  | 'safety_flagged';

export interface AuditLogParams {
  userId?: string | null;
  actor: AuditActor;
  action: AuditAction;
  metadata?: Record<string, unknown> | null;
}

/**
 * Writes an immutable compliance entry to the audit_log table.
 * Used to verify confidentiality, right-to-erasure compliance, and justified access.
 */
export async function recordAuditLog({
  userId,
  actor,
  action,
  metadata = null,
}: AuditLogParams) {
  try {
    return await prisma.auditLog.create({
      data: {
        userId: userId || null,
        actor,
        action,
        metadata: metadata ? (metadata as Prisma.InputJsonValue) : Prisma.DbNull,
      },
    });
  } catch (err) {
    console.error('CRITICAL: Failed to write compliance audit_log entry:', err);
    // Audit log write failure should be surfaced in telemetry
    return null;
  }
}
