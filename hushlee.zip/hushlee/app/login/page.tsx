'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Lock, Mail, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { signIn } from 'next-auth/react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }
    setError(null);
    setLoading(true);

    try {
      // Use direct email authentication (Auth.js)
      const res = await signIn('email-login', {
        email,
        redirect: false,
        callbackUrl: '/chat',
      });

      if (res?.error) {
        setError(res.error);
      } else {
        setSent(true);
        window.location.href = '/chat';
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error sending sign-in link';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#2C3333] flex flex-col justify-between selection:bg-[#E2D4C9]">
      <header className="border-b border-[#EAE3D9] bg-[#FAF8F5]/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-6 h-18 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-[#5D7052] flex items-center justify-center text-white font-medium text-lg">
              H
            </span>
            <span className="font-serif text-2xl tracking-tight text-[#1F2421]">Hushlee</span>
          </Link>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#EFECE6] text-xs font-medium text-[#4A5548] border border-[#DDD7CD]">
            <Lock className="w-3.5 h-3.5 text-[#5D7052]" />
            <span>Confidential & Passwordless</span>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-md mx-auto px-6 py-16 flex flex-col justify-center w-full">
        <div className="bg-white/90 border border-[#E8E1D7] rounded-3xl p-8 shadow-xs">
          <div className="w-12 h-12 rounded-2xl bg-[#EFECE6] flex items-center justify-center text-[#5D7052] mb-6">
            <Mail className="w-6 h-6" />
          </div>

          <h1 className="font-serif text-3xl text-[#1F2421] mb-2">Sign in to Hushlee</h1>
          <p className="text-sm text-[#5A6460] leading-relaxed mb-6">
            Enter your email to receive a secure login link. No passwords, no data broker trackers.
          </p>

          {sent ? (
            <div className="p-4 rounded-2xl bg-[#EBF3E8] border border-[#C5DEC0] text-[#335629] text-sm flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Sign in successful</p>
                <p className="text-xs mt-1 text-[#456A3A]">Redirecting you to your confidential chat...</p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs border border-red-200">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-[#4A5548] mb-1.5">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full text-sm p-3.5 rounded-xl bg-white border border-[#E0D7CC] text-[#2C3333] placeholder-[#A0AAA5] focus:outline-none focus:ring-1 focus:ring-[#5D7052]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-full bg-[#5D7052] text-white font-medium text-sm hover:bg-[#4D5E44] transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-60"
              >
                <span>{loading ? 'Sending Link...' : 'Continue with Magic Link'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          <div className="mt-8 pt-6 border-t border-[#F0ECE6] text-xs text-[#7B8580] space-y-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#5D7052]" />
              <span>We never sell or share your email address</span>
            </div>
            <p className="text-[11px] text-[#9A9E9C] leading-normal">
              By continuing, you agree to our 90-day retention auto-purge policy and confirm understanding that Hushlee is an AI coach, not a licensed therapist.
            </p>
          </div>
        </div>
      </main>

      <footer className="border-t border-[#EAE3D9] py-6 text-center text-xs text-[#7B8580]">
        Hushlee — Confidential AI Relationship Coach
      </footer>
    </div>
  );
}
