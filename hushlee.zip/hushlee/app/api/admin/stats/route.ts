import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const runtime = 'nodejs';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const key = searchParams.get('key') || req.headers.get('x-admin-key');
    const adminSecret = process.env.ADMIN_SECRET || 'hushlee-admin-2026';

    if (key !== adminSecret) {
      return NextResponse.json({ error: 'Unauthorized: Invalid Admin Key' }, { status: 401 });
    }

    const now = new Date();
    const day24hAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const day7dAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const day30dAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    // 1. High-level KPIs in parallel with batching
    const [
      totalUsers,
      consentedUsers,
      totalConversations,
      totalMessages,
      totalSafetyFlags,
      activeLogs30d,
      recentMessages,
      recentConversations,
      consentLogs,
      safetyFlagsGrouped,
      recentAuditLogs,
    ] = await Promise.all([
      prisma.user.count({ where: { deletedAt: null } }),
      prisma.user.count({ where: { deletedAt: null, consentBackupAckAt: { not: null } } }),
      prisma.conversation.count({ where: { archivedAt: null } }),
      prisma.message.count(),
      prisma.safetyFlag.count(),
      prisma.auditLog.findMany({
        where: {
          action: 'message_sent',
          createdAt: { gte: day30dAgo },
          userId: { not: null },
        },
        select: { userId: true, createdAt: true },
      }),
      prisma.message.findMany({
        where: { createdAt: { gte: day7dAgo } },
        select: { createdAt: true },
      }),
      prisma.conversation.findMany({
        where: { createdAt: { gte: day7dAgo } },
        select: { createdAt: true },
      }),
      prisma.auditLog.findMany({
        where: { action: 'consent_given' },
        select: { metadata: true },
      }),
      prisma.safetyFlag.groupBy({
        by: ['category'],
        _count: { category: true },
      }),
      prisma.auditLog.findMany({
        orderBy: { createdAt: 'desc' },
        take: 15,
        select: {
          id: true,
          actor: true,
          action: true,
          metadata: true,
          createdAt: true,
        },
      }),
    ]);

    // Active users calculation (in-memory from 30d logs)
    const dauSet = new Set(
      activeLogs30d
        .filter((l) => new Date(l.createdAt) >= day24hAgo)
        .map((l) => l.userId)
    );
    const wauSet = new Set(
      activeLogs30d
        .filter((l) => new Date(l.createdAt) >= day7dAgo)
        .map((l) => l.userId)
    );
    const mauSet = new Set(activeLogs30d.map((l) => l.userId));
    const dau = dauSet.size;
    const wau = wauSet.size;
    const mau = mauSet.size;

    // 2. Audience Breakdown
    const relationshipCounts: Record<string, number> = {
      romantic: 0,
      family: 0,
      friendship: 0,
      workplace: 0,
      other: 0,
    };

    for (const log of consentLogs) {
      if (log.metadata && typeof log.metadata === 'object') {
        const meta = log.metadata as Record<string, unknown>;
        const rel = String(meta.relationshipType || 'other').toLowerCase();
        if (rel in relationshipCounts) {
          relationshipCounts[rel]++;
        } else {
          relationshipCounts.other++;
        }
      }
    }

    const totalCategorySelections = Math.max(consentLogs.length, 1);
    const relationshipBreakdown = Object.entries(relationshipCounts).map(([category, count]) => ({
      category,
      count,
      percentage: Math.round((count / totalCategorySelections) * 100),
    }));

    // 3. Safety Breakdown
    const safetyBreakdown = safetyFlagsGrouped.map((item) => ({
      category: item.category,
      count: item._count.category,
    }));

    // 4. Daily Activity (Calculated in-memory instantly, no separate DB round-trips)
    const dayOffsets = [6, 5, 4, 3, 2, 1, 0];
    const dailyActivity = dayOffsets.map((i) => {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const dateStr = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

      const startOfDay = new Date(d);
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date(d);
      endOfDay.setHours(23, 59, 59, 999);

      const msgCount = recentMessages.filter(
        (m) => m.createdAt >= startOfDay && m.createdAt <= endOfDay
      ).length;
      const convCount = recentConversations.filter(
        (c) => c.createdAt >= startOfDay && c.createdAt <= endOfDay
      ).length;

      return {
        date: dateStr,
        messages: msgCount,
        conversations: convCount,
      };
    });

    return NextResponse.json({
      overview: {
        totalUsers,
        consentedUsers,
        consentRate: totalUsers > 0 ? Math.round((consentedUsers / totalUsers) * 100) : 100,
        totalConversations,
        totalMessages,
        avgMessagesPerConv:
          totalConversations > 0 ? Math.round((totalMessages / totalConversations) * 10) / 10 : 0,
        dau,
        wau,
        mau,
        totalSafetyFlags,
      },
      relationshipBreakdown,
      safetyBreakdown,
      dailyActivity,
      recentAuditLogs,
      retentionStatus: {
        windowDays: 90,
        nextAutoPurge: 'Daily at 03:00 UTC',
        complianceStatus: 'Active',
      },
    });
  } catch (err: unknown) {
    console.error('Admin stats error:', err);
    const msg = err instanceof Error ? err.message : 'Internal Server Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
