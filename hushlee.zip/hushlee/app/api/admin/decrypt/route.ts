import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { decryptUserMessage } from '@/lib/encryption';
import { recordAuditLog } from '@/lib/audit';

export const runtime = 'nodejs';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { passkey, userId, reason, adminId } = body;

    const adminSecret = process.env.ADMIN_SECRET || 'hushlee-admin-2026';
    if (passkey !== adminSecret) {
      return NextResponse.json({ error: 'Unauthorized: Invalid Admin Passkey' }, { status: 401 });
    }

    if (!userId || !reason || reason.trim().length < 10) {
      return NextResponse.json(
        { error: 'A valid target User ID and detailed justification (min 10 characters) are required.' },
        { status: 400 }
      );
    }

    // 1. Locate user
    const user = await prisma.user.findFirst({
      where: {
        OR: [{ id: userId }, { email: userId }],
      },
      include: {
        conversations: {
          orderBy: { createdAt: 'desc' },
          include: {
            messages: {
              orderBy: { createdAt: 'asc' },
              select: {
                id: true,
                role: true,
                contentEncrypted: true,
                createdAt: true,
              },
            },
          },
        },
      },
    });

    if (!user) {
      return NextResponse.json({ error: `User not found: ${userId}` }, { status: 404 });
    }

    // 2. Mandatory Audit Logging BEFORE releasing decrypted data
    await recordAuditLog({
      userId: user.id,
      actor: 'admin',
      action: 'admin_access',
      metadata: {
        adminId: adminId || 'admin-portal',
        reason: reason.trim(),
        targetUserId: user.id,
        conversationsCount: user.conversations.length,
        accessedAt: new Date().toISOString(),
      },
    });

    // 3. Decrypt all conversation messages
    const decryptedConversations = await Promise.all(
      user.conversations.map(async (conv) => {
        const decryptedMessages = await Promise.all(
          conv.messages.map(async (msg) => {
            let content = '';
            try {
              content = await decryptUserMessage(user.id, msg.contentEncrypted);
            } catch (err) {
              const msgErr = err instanceof Error ? err.message : 'Decryption error';
              content = `[Decryption failed: ${msgErr}]`;
            }
            return {
              id: msg.id,
              role: msg.role,
              content,
              createdAt: msg.createdAt,
            };
          })
        );

        return {
          id: conv.id,
          title: conv.title,
          createdAt: conv.createdAt,
          messages: decryptedMessages,
        };
      })
    );

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        createdAt: user.createdAt,
        consentBackupAckAt: user.consentBackupAckAt,
      },
      conversations: decryptedConversations,
    });
  } catch (err: unknown) {
    console.error('Admin decrypt error:', err);
    const msg = err instanceof Error ? err.message : 'Internal Server Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
