import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/session';
import { prisma } from '@/lib/db';
import { getOrCreateUserDek } from '@/lib/encryption';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { consentGiven, relationshipType, initialContext } = body;

    if (!consentGiven) {
      return NextResponse.json(
        { error: 'Explicit consent to 90-day retention and privacy policy is required.' },
        { status: 400 }
      );
    }

    const currentUser = await getCurrentUser();
    const timestamp = new Date();

    // 1. Update user record with consent timestamp
    const updatedUser = await prisma.user.update({
      where: { id: currentUser.id },
      data: {
        consentBackupAckAt: timestamp,
      },
    });

    // 2. Ensure DEK is initialized
    await getOrCreateUserDek(currentUser.id);

    // 3. Write to audit_log
    await prisma.auditLog.create({
      data: {
        userId: currentUser.id,
        actor: 'user',
        action: 'consent_given',
        metadata: {
          retentionWindowDays: 90,
          relationshipType: relationshipType || 'general',
          hasInitialContext: Boolean(initialContext),
          consentedAt: timestamp.toISOString(),
        },
      },
    });

    return NextResponse.json({
      success: true,
      consentBackupAckAt: updatedUser.consentBackupAckAt,
    });
  } catch (err: unknown) {
    console.error('Error recording onboarding consent:', err);
    const message = err instanceof Error ? err.message : 'Internal Server Error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
