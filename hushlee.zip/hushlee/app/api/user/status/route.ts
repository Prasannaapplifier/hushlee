import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/session';

export async function GET() {
  try {
    const user = await getCurrentUser();
    return NextResponse.json({
      id: user.id,
      email: user.email,
      consentBackupAckAt: user.consentBackupAckAt,
      hasConsented: Boolean(user.consentBackupAckAt),
      isGuest: user.isGuest,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Error checking user status';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
