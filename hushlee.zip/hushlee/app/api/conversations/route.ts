import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/session';
import { prisma } from '@/lib/db';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user.consentBackupAckAt) {
      return NextResponse.json({ error: 'Consent required' }, { status: 403 });
    }

    const conversations = await prisma.conversation.findMany({
      where: {
        userId: user.id,
        archivedAt: null,
      },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        title: true,
        createdAt: true,
      },
    });

    return NextResponse.json({ conversations });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Error fetching conversations';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user.consentBackupAckAt) {
      return NextResponse.json({ error: 'Consent required' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const title = body.title || 'New Reflection';

    const conversation = await prisma.conversation.create({
      data: {
        userId: user.id,
        title,
      },
    });

    return NextResponse.json({ conversation });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Error creating conversation';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
