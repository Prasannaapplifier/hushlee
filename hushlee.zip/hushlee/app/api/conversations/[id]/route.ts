import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/session';
import { prisma } from '@/lib/db';
import { decryptUserMessage } from '@/lib/encryption';

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function GET(req: Request, context: RouteContext) {
  try {
    const { id } = await context.params;
    const user = await getCurrentUser();

    if (!user.consentBackupAckAt) {
      return NextResponse.json({ error: 'Consent required' }, { status: 403 });
    }

    const conversation = await prisma.conversation.findFirst({
      where: {
        id,
        userId: user.id,
      },
      include: {
        messages: {
          orderBy: { createdAt: 'asc' },
          select: {
            id: true,
            role: true,
            contentEncrypted: true,
            createdAt: true,
            safetyFlags: {
              select: {
                id: true,
                category: true,
                severity: true,
              },
            },
          },
        },
      },
    });

    if (!conversation) {
      return NextResponse.json({ error: 'Conversation not found' }, { status: 404 });
    }

    // Decrypt messages on the fly for the authenticated user
    const decryptedMessages = await Promise.all(
      conversation.messages.map(async (msg) => {
        let content = '';
        try {
          content = await decryptUserMessage(user.id, msg.contentEncrypted);
        } catch {
          content = '[Decryption failed: Key mismatch or malformed ciphertext]';
        }
        return {
          id: msg.id,
          role: msg.role,
          content,
          createdAt: msg.createdAt,
          safetyFlags: msg.safetyFlags,
        };
      })
    );

    return NextResponse.json({
      conversation: {
        id: conversation.id,
        title: conversation.title,
        createdAt: conversation.createdAt,
        messages: decryptedMessages,
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Error fetching conversation';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(req: Request, context: RouteContext) {
  try {
    const { id } = await context.params;
    const user = await getCurrentUser();

    await prisma.conversation.deleteMany({
      where: {
        id,
        userId: user.id,
      },
    });

    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Error deleting conversation';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
