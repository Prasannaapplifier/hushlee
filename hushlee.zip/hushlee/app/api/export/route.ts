import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/session';
import { prisma } from '@/lib/db';
import { decryptUserMessage } from '@/lib/encryption';
import { recordAuditLog } from '@/lib/audit';

export async function GET() {
  try {
    const user = await getCurrentUser();

    // 1. Mandatory audit log entry for compliance
    await recordAuditLog({
      userId: user.id,
      actor: 'user',
      action: 'export_requested',
      metadata: {
        exportedAt: new Date().toISOString(),
      },
    });

    // 2. Fetch all user data
    const dbUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        email: true,
        consentBackupAckAt: true,
        createdAt: true,
        conversations: {
          orderBy: { createdAt: 'desc' },
          include: {
            messages: {
              orderBy: { createdAt: 'asc' },
              select: {
                id: true,
                role: true,
                contentEncrypted: true,
                createdAt: true,
              },
            },
          },
        },
      },
    });

    if (!dbUser) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // 3. Decrypt all conversation messages
    const exportedConversations = await Promise.all(
      dbUser.conversations.map(async (conv) => {
        const decryptedMessages = await Promise.all(
          conv.messages.map(async (msg) => {
            let content = '';
            try {
              content = await decryptUserMessage(user.id, msg.contentEncrypted);
            } catch {
              content = '[Message content could not be decrypted]';
            }
            return {
              id: msg.id,
              role: msg.role,
              content,
              createdAt: msg.createdAt,
            };
          })
        );

        return {
          id: conv.id,
          title: conv.title,
          createdAt: conv.createdAt,
          messages: decryptedMessages,
        };
      })
    );

    // 4. Assemble clean privacy export object
    const exportData = {
      exportVersion: '1.0',
      exportedAt: new Date().toISOString(),
      confidentialityPledge:
        'Hushlee does not sell or share user data. Conversations are retained for 90 days.',
      user: {
        id: dbUser.id,
        email: dbUser.email,
        consentBackupAckAt: dbUser.consentBackupAckAt,
        accountCreatedAt: dbUser.createdAt,
      },
      conversations: exportedConversations,
    };

    const jsonString = JSON.stringify(exportData, null, 2);

    return new Response(jsonString, {
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="hushlee-data-export-${new Date().toISOString().slice(0, 10)}.json"`,
      },
    });
  } catch (err: unknown) {
    console.error('Export error:', err);
    const msg = err instanceof Error ? err.message : 'Internal Server Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
