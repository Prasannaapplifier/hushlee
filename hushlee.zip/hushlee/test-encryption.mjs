import crypto from 'crypto';

// Replicate Hushlee cryptographic routines for unit testing
const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12;
const KEY_LENGTH = 32;

function encryptWithKey(plainData, key) {
  const dataBuffer = Buffer.isBuffer(plainData) ? plainData : Buffer.from(plainData, 'utf8');
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);

  const encryptedBuffer = Buffer.concat([cipher.update(dataBuffer), cipher.final()]);
  const authTag = cipher.getAuthTag();

  return {
    v: 1,
    alg: ALGORITHM,
    iv: iv.toString('base64'),
    authTag: authTag.toString('base64'),
    ciphertext: encryptedBuffer.toString('base64'),
  };
}

function decryptWithKey(payload, key) {
  if (payload.v !== 1) throw new Error('Unsupported version');
  const iv = Buffer.from(payload.iv, 'base64');
  const authTag = Buffer.from(payload.authTag, 'base64');
  const ciphertext = Buffer.from(payload.ciphertext, 'base64');

  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(authTag);

  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

console.log('--- Hushlee Cryptographic Verification ---');

// 1. Master Key (KEK)
const masterKey = crypto.randomBytes(KEY_LENGTH);
console.log('✓ Master Key generated (256-bit):', masterKey.toString('hex').slice(0, 16) + '...');

// 2. User DEK generated and encrypted by Master Key (Envelope pattern)
const userDek = crypto.randomBytes(KEY_LENGTH);
const encryptedDekEnvelope = encryptWithKey(userDek, masterKey);
console.log('✓ User DEK encrypted with Master Key (AES-256-GCM envelope):', encryptedDekEnvelope.ciphertext.slice(0, 20) + '...');

// 3. Decrypt User DEK with Master Key
const decryptedDek = decryptWithKey(encryptedDekEnvelope, masterKey);
if (decryptedDek.equals(userDek)) {
  console.log('✓ DEK unwrapped successfully with Master Key. Matches original.');
} else {
  console.error('✗ DEK mismatch!');
  process.exit(1);
}

// 4. Message Content Encryption using User DEK
const sensitiveMessage = 'My partner and I had a painful disagreement about our future living arrangements.';
const encryptedMessage = encryptWithKey(sensitiveMessage, userDek);
console.log('✓ Message encrypted at field level:');
console.log('  Ciphertext:', encryptedMessage.ciphertext);
console.log('  IV (base64):', encryptedMessage.iv);
console.log('  AuthTag (base64):', encryptedMessage.authTag);

// 5. Message Content Decryption
const decryptedMessage = decryptWithKey(encryptedMessage, userDek).toString('utf8');
if (decryptedMessage === sensitiveMessage) {
  console.log('✓ Message successfully decrypted with User DEK. Content matched 100%.');
} else {
  console.error('✗ Message content mismatch!');
  process.exit(1);
}

// 6. Tampering resistance test (GCM authentication check)
let tamperFailed = false;
try {
  const tamperedPayload = { ...encryptedMessage, authTag: crypto.randomBytes(16).toString('base64') };
  decryptWithKey(tamperedPayload, userDek);
} catch {
  tamperFailed = true;
  console.log('✓ GCM Auth Tag integrity check verified: Tampered ciphertext rejected.');
}

if (!tamperFailed) {
  console.error('✗ GCM failed to detect tampering!');
  process.exit(1);
}

console.log('--- All Field-Level Envelope Encryption Tests Passed! ---');
