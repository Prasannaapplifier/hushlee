# Hushlee — Confidential AI Relationship Coach

> *"What you share stays private. We never sell your data, and we never share it with third parties."*

Hushlee is a confidential AI relationship coach built to help individuals reflect on relational dynamics (romantic, family, friendship, workplace) in an unhurried, calm, and private space.

---

## Core Pillars & Trust Architecture

1. **Coach, Not Licensed Therapist:**
   * Hushlee provides communication frameworks, perspective-taking, and guided reflection.
   * It is explicitly not a licensed therapist, psychologist, medical service, or emergency crisis hotline.
2. **Zero Data Brokering:**
   * User data is never sold to advertisers or data brokers.
   * User conversations are never shared with third parties or used for commercial AI model training.
3. **Field-Level Envelope Encryption (AES-256-GCM):**
   * Message contents are encrypted before ever touching PostgreSQL (`messages.content_encrypted`).
   * Uses an envelope encryption pattern: per-user Data Encryption Keys (DEKs) wrapped by a 256-bit Master Key (KEK).
4. **90-Day Retention Policy & Auto-Purge:**
   * Conversations are automatically purged after 90 days by a scheduled background cron job.
   * Explicit user consent is logged before chat access is granted.
5. **Safety & Crisis Escalation Layer:**
   * Server-side evaluation for self-harm, intimate partner violence/abuse disclosures, and acute crises.
   * Dynamic tone shift to gentle de-escalation and automatic surfacing of context-specific hotlines (988 Lifeline, Crisis Text Line, National Domestic Violence Hotline).
   * Discreet logging to `safety_flags` without exposing surveillance-style alerts to the user.

---

## Tech Stack

| Layer | Technology | Rationale |
|---|---|---|
| **Frontend & Backend** | Next.js 16 (App Router) + TypeScript + Tailwind CSS | Streaming chat UX, server actions, and type safety |
| **Hosting** | Render (Standard Node.js runtime) | Full Node crypto support required for AES-256-GCM envelope encryption |
| **Database** | PostgreSQL (Render Managed Postgres) + Prisma ORM | Relational data integrity, cascade deletion, and audit logging |
| **LLM** | Claude API (`@anthropic-ai/sdk`, Messages API, streaming) | Server-side invocation with warm, non-clinical system prompt |
| **Auth** | Auth.js (NextAuth v5) | Passwordless email magic-link login via `@auth/prisma-adapter` |
| **Encryption** | Node.js native `crypto` | Field-level envelope encryption with 96-bit IVs and 128-bit auth tags |
| **Cron Cleaner** | Render Cron Job | Daily execution of 90-day auto-purge retention cleaner |

---

## Directory Layout (SPEC.md Section 8)

```
/app
  /(marketing)/page.tsx          -- Landing page (confidentiality pledge, no-sale promise)
  /chat/page.tsx                 -- Main chat UI with streaming & history sidebar
  /settings/page.tsx             -- Privacy settings, data export, and deletion controls
  /login/page.tsx                -- Passwordless email magic-link sign in
  /api/chat/route.ts             -- Streams from Claude, writes encrypted messages
  /api/conversations/route.ts    -- Lists & creates user conversations
  /api/conversations/[id]/route.ts -- Decrypts messages on-the-fly for authenticated user
  /api/export/route.ts           -- Self-service GDPR/DPDP decrypted JSON data export
  /api/delete/route.ts           -- Self-service conversation purge and account deletion
  /api/onboarding/consent/route.ts -- Records 90-day retention consent timestamp
  /api/user/status/route.ts      -- Verifies session and consent status
/lib
  /claude.ts                     -- Claude API client & relationship coach system prompts
  /encryption.ts                 -- Field-level envelope encryption (AES-256-GCM)
  /safety.ts                     -- Server-side safety classifier (self-harm, abuse, crisis)
  /audit.ts                      -- Immutable compliance audit logging service
  /session.ts                    -- Session management (Auth.js & guest fallback)
  /db.ts                         -- Prisma Client singleton
/components
  /Chat/                         -- ChatSidebar, ChatMessage, ChatComposer, CrisisResourcePanel, ConfidentialityModal
  /Onboarding/                   -- 3-step onboarding flow modal with mandatory retention consent
  /Settings/                     -- Settings sections
/prisma
  schema.prisma                  -- PostgreSQL schema (users, conversations, messages, audit_log, safety_flags)
  schema.sql                     -- Raw PostgreSQL DDL
/scripts
  auto-purge.mjs                 -- 90-day retention auto-purge cron script
render.yaml                      -- Render Infrastructure as Code Blueprint
SPEC.md                          -- Core Product & Technical Specification
```

---

## Required Environment Variables

Create a `.env` file in the project root based on `.env.example`:

```bash
cp .env.example .env
```

| Variable | Description | Example / Generation |
|---|---|---|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@host:5432/hushlee?schema=public` |
| `CLAUDE_API_KEY` | Anthropic Claude Messages API Key | `sk-ant-api03-...` (Required for live Claude responses) |
| `ENCRYPTION_MASTER_KEY` | 256-bit hexadecimal key used to encrypt user DEKs | Generate via: `openssl rand -hex 32` |
| `AUTH_SECRET` | NextAuth secret for session tokens & JWT signing | Generate via: `openssl rand -base64 32` |
| `NEXTAUTH_URL` | Canonical app URL | `http://localhost:3000` (or `https://your-domain.com`) |
| `EMAIL_SERVER_HOST` | *(Optional)* SMTP host for magic-link delivery | `smtp.resend.com` |
| `EMAIL_SERVER_PORT` | *(Optional)* SMTP port | `587` |
| `EMAIL_SERVER_USER` | *(Optional)* SMTP username | `resend` |
| `EMAIL_SERVER_PASSWORD` | *(Optional)* SMTP password | API Key / Password |
| `EMAIL_FROM` | Sender address for magic links | `Hushlee <coach@hushlee.app>` |

> **Security Note:** Never commit `.env` or production secrets to version control. Only `.env.example` is tracked.

---

## Local Development Quickstart

### 1. Install Dependencies
```bash
npm install
```

### 2. Generate Prisma Client
```bash
npx prisma generate
```

### 3. Initialize PostgreSQL Database
If you have a local or cloud Postgres database, run:
```bash
npx prisma db push
```
*(Or execute `prisma/schema.sql` directly into your Postgres console.)*

### 4. Start Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## Testing & Verification Scripts

### 1. Test Field-Level Envelope Encryption & Tamper Resistance
Verifies DEK wrapping, message encryption/decryption, and GCM authentication tag integrity:
```bash
node test-encryption.mjs
```

### 2. Test Safety Classifier
Verifies accurate categorization of self-harm, intimate partner abuse disclosures, and unflagged healthy reflections:
```bash
node test-safety.mjs
```

### 3. Test 90-Day Auto-Purge Retention Cleaner
Simulates the daily cron job that purges conversations and messages older than 90 days and writes an audit log entry:
```bash
npm run purge
```

---

## Deploying to Render

This repository includes a [`render.yaml`](./render.yaml) blueprint that provisions:
1. **Web Service (`hushlee-app`):** Next.js App Router running on Render's standard Node.js runtime.
2. **Managed Postgres (`hushlee-postgres`):** Production PostgreSQL database automatically linked via `DATABASE_URL`.
3. **Cron Job (`hushlee-retention-purge`):** Scheduled daily at `03:00 UTC` to execute `npm run purge`.

### Steps to Deploy:
1. Push your repository to GitHub / GitLab.
2. Log in to [Render Dashboard](https://dashboard.render.com).
3. Click **New +** → **Blueprint**.
4. Select your Hushlee repository.
5. Set `CLAUDE_API_KEY` and `ENCRYPTION_MASTER_KEY` under the Environment configuration.
6. Click **Apply** to automatically provision the web app, database, and retention cron job.

---

## Privacy & Compliance Auditing

* **Audit Log:** Every message sent, data export, privileged admin access, and retention deletion is recorded in the `audit_log` table with actors (`user`, `system`, `admin`).
* **Admin Access Safeguard:** `adminDecryptMessage()` in `lib/encryption.ts` strictly requires a documented justification reason and logs `action: 'admin_access'` prior to releasing any decrypted plaintext.
* **Self-Service Erasure:** Users can instantly purge conversation reflections or completely delete their account and encryption keys directly from `/settings`.
