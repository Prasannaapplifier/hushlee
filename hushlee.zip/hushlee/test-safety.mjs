// Replicate safety patterns for verification
const SELF_HARM_PATTERNS = [
  /\b(kill myself|killing myself|suicid(e|al)|want to die|wanna die|end my life|ending it all)\b/i,
  /\b(take my own life|better off dead|wish i was dead|wish i were dead|no reason to live)\b/i,
  /\b(hang myself|slit my (wrists|throat)|overdose|cut myself|cutting myself|hurt myself intentionally)\b/i,
  /\b(can'?t go on living|goodbye everyone|don'?t want to wake up)\b/i,
  /\b(planning to die|giving away my things|swallowed a bunch of pills)\b/i,
];

const ABUSE_PATTERNS = [
  /\b(hits? me|hitting me|beat(s|ing)? me|punched me|slapped me|kicked me|choked me|choking me)\b/i,
  /\b(physically (abused|hurts|hurt me)|bruised me|broke my (arm|finger|nose|rib))\b/i,
  /\b(threatened to (kill|shoot|stab|harm|burn) me|threatens to kill me)\b/i,
  /\b(forced me to have sex|sexual(ly)? assaulted|raped me|coerced me into sex)\b/i,
  /\b(locked me in (the room|the house|a closet)|won'?t let me leave the house|took my passport)\b/i,
  /\b(afraid (he|she|they) (will|might) kill me|scared for my physical life|afraid for my life)\b/i,
  /\b(holds a (gun|knife) to me|threatening me with a (gun|knife))\b/i,
];

function evaluateSafety(content) {
  const normalized = content.trim().toLowerCase();
  for (const pattern of SELF_HARM_PATTERNS) {
    if (pattern.test(normalized)) {
      return { flagged: true, category: 'self_harm' };
    }
  }
  for (const pattern of ABUSE_PATTERNS) {
    if (pattern.test(normalized)) {
      return { flagged: true, category: 'abuse_disclosure' };
    }
  }
  return { flagged: false };
}

console.log('--- Hushlee Safety & Escalation Classifier Tests ---');

// Test Case 1: Normal relationship conflict
const normalTest = evaluateSafety("My partner and I had an argument about balancing housework and personal time.");
if (!normalTest.flagged) {
  console.log('✓ Normal relationship message: correctly unflagged.');
} else {
  console.error('✗ Normal message was incorrectly flagged!');
  process.exit(1);
}

// Test Case 2: Self-harm disclosure
const selfHarmTest = evaluateSafety("I feel so overwhelmed and hopeless that I just want to end my life.");
if (selfHarmTest.flagged && selfHarmTest.category === 'self_harm') {
  console.log('✓ Self-harm disclosure: correctly flagged as category "self_harm".');
} else {
  console.error('✗ Self-harm detection failed!');
  process.exit(1);
}

// Test Case 3: Domestic abuse disclosure
const abuseTest = evaluateSafety("Last night he got furious, threw a chair, and slapped me across the face.");
if (abuseTest.flagged && abuseTest.category === 'abuse_disclosure') {
  console.log('✓ Abuse disclosure: correctly flagged as category "abuse_disclosure".');
} else {
  console.error('✗ Abuse disclosure detection failed!');
  process.exit(1);
}

console.log('--- All Safety & Escalation Classifier Tests Passed! ---');
