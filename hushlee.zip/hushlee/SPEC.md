# Hushlee — Product & Technical Spec
### Confidential AI Relationship Coach

## 1. Product Positioning

**What it is:** A web app where users chat 1:1 with an AI relationship coach (powered by Claude) about their relationship — romantic, family, friendship, or workplace dynamics.

**Core promise:** *"What you share stays private. We never sell your data, and we never share it with third parties."* Confidentiality is the product's main trust signal, so it needs to be visible, not just written in a privacy policy — see Section 5.

> **A note on "never leaves our server" claims:** One thing to get right before you put this in marketing copy — your chat messages *do* have to be sent to the Claude API to generate a response, so they technically transit to Anthropic's infrastructure for processing (this is true of any product built on a third-party LLM API). What you *can* honestly and confidently claim is: you don't sell the data, you don't share it with advertisers or data brokers, you don't use it for any purpose beyond generating the user's own coaching responses, and Anthropic's API terms mean your data isn't used to train their models by default. "Never leaves our infrastructure" would be a false claim if challenged; "never sold, never shared with third parties, used only to serve you" is the accurate and still very strong version. I've written the copy below using that framing — swap in your own wording, but keep the underlying claim honest.

**Important framing to bake in from day one:**
- This is a *coach*, not a licensed therapist or counselor. Say this explicitly in onboarding and in the system prompt. It reduces liability and sets correct user expectations.
- Build a **safety layer** that detects disclosures of self-harm, suicidal ideation, or abuse, and responds with appropriate care + hands off to real resources (crisis lines, domestic violence hotlines) rather than trying to "coach" through them. This is both an ethical requirement and a legal-risk reducer.

---

## 2. Tech Stack

| Layer | Choice | Why |
|---|---|---|
| Frontend | Next.js (App Router) + TypeScript + Tailwind | Fast to scaffold with an AI coding agent, good SSR/streaming support for chat UX |
| Backend | Next.js API routes or a separate Node/Express service | Keep the Claude API key server-side only, never in the client |
| LLM | Claude API (Messages API, streaming) | Coach persona lives in a system prompt server-side |
| Auth | Clerk or Auth.js (NextAuth) | Passwordless/email or OAuth login — keep signup low-friction |
| Database | PostgreSQL (Render managed Postgres) | Relational, supports row-level security, good for compliance auditing; same host as app, native cron support for the retention/auto-purge job |
| Encryption | Envelope encryption at the field level (see Section 5) | Message bodies encrypted at rest |
| Hosting | Render (Node.js runtime, standard — not edge) | Fast to ship, scales fine for MVP, avoids edge-runtime crypto limitations |
| Backups | Encrypted, access-logged, time-boxed retention | Not "just a DB backup" — treat as a compliance artifact |

---

## 3. System Architecture

```
┌─────────────┐      HTTPS       ┌──────────────────┐      HTTPS       ┌─────────────┐
│   Browser    │ ───────────────▶ │  Next.js Backend  │ ───────────────▶ │ Claude API   │
│ (React UI)   │ ◀─── stream ──── │  (API routes)      │ ◀─── stream ──── │ (Messages)   │
└─────────────┘                  └──────────────────┘                  └─────────────┘
                                          │
                                          │ encrypted write
                                          ▼
                                  ┌──────────────────┐
                                  │   PostgreSQL       │
                                  │  - users            │
                                  │  - conversations    │
                                  │  - messages (enc.)  │
                                  │  - audit_log        │
                                  └──────────────────┘
```

Key principle: **the browser never talks to Claude directly.** All calls go through your backend, so you control what gets logged, retained, and redacted, and the API key never leaves the server.

---

## 4. Data Model (starting point)

```sql
users (
  id, email, created_at, deleted_at,
  consent_backup_ack_at   -- timestamp they accepted the retention policy
)

conversations (
  id, user_id, title, created_at, archived_at
)

messages (
  id, conversation_id, role, content_encrypted, created_at
)

audit_log (
  id, user_id, actor,        -- 'user' | 'system' | 'admin'
  action,                    -- 'message_sent' | 'export_requested' | 'admin_access' | 'deletion_requested'
  created_at, metadata
)

safety_flags (
  id, message_id, category,  -- 'self_harm' | 'abuse_disclosure' | 'crisis'
  reviewed, created_at
)
```

`audit_log` and `safety_flags` matter more than people expect — they're what let you *prove* confidentiality was respected and that crisis situations were handled correctly, if it's ever questioned.

---

## 5. Confidentiality & Compliance Design (the core differentiator)

This is the part to get right, since it's your main selling point.

**Encryption**
- Encrypt message content at the field level (not just "disk encryption") using envelope encryption — a per-user data key, itself encrypted by a master key in a KMS (AWS KMS / Google Cloud KMS / Supabase Vault).
- Even admins/support staff should not be able to read raw messages without a logged, justified access event.

**Retention policy (the legal-compliance backups)**
- Retention window: **90 days** (confirm this against actual jurisdictional requirements before launch — see the legal-groundwork note below). State it in plain language in the UI, not buried in a ToS.
- Backups should be encrypted separately from the live DB and access-logged.
- Auto-purge on schedule — don't keep data "just in case" beyond what's declared.

**No-sale, no-sharing commitment**
- State it explicitly, in plain language, in at least three places: landing page, onboarding, and settings — *"We do not sell your data. We do not share it with advertisers, data brokers, or any third party. It is used only to generate your coaching responses and is never used for marketing, analytics resale, or model training beyond what's needed to run this service."*
- Back this with an actual internal policy: no analytics tools that pipe message content to third-party vendors (e.g. don't route raw chat text through generic product-analytics SaaS), no ad pixels on the chat screen, no data-sharing clauses in any future partnership or investor deal without re-consenting users.
- If/when you monetize, monetize via subscription — not data. Say so. "We make money when you subscribe, not by selling your data" is a strong trust line and keeps the incentive structure honest.

**User-facing trust signals**
- A persistent "🔒 Confidential — never sold or shared" badge in the chat UI.
- A short, plain-English explainer accessible from the chat screen: *what's stored, for how long, who can see it (nobody, by default), why it's processed at all (to generate the response), and the explicit no-sale/no-share commitment.*
- Self-service data export and deletion request (builds trust and covers you for GDPR/DPDP-style right-to-erasure obligations — relevant given your India/Singapore/UAE/US market mix).

**Legal groundwork (not code, but do this before launch)**
- Consult a lawyer on: which jurisdiction's data protection law governs you (India's DPDP Act, GDPR if any EU users, etc.), whether relationship-coaching content counts as sensitive personal data, and what your actual legal retention obligation is (it may be *shorter* than you think — "keep everything forever for compliance" is a common misconception).
- Terms of Service should clearly state the coach is not a substitute for therapy/legal/medical advice.

---

## 6. Safety & Escalation Layer

- Server-side, on every user message before/alongside the Claude call: run a lightweight classifier (can be a Claude call itself, or a cheaper heuristic) for self-harm risk, abuse disclosure, or crisis language.
- If flagged: the coach's response shifts tone (calm, validating, non-judgmental) and includes real crisis resources appropriate to the user's country — don't try to "coach" through an acute crisis.
- Log the flag in `safety_flags` for review, but never expose this flagging mechanism to the user in a way that feels like surveillance.

---

## 7. UI/UX Structure

**Screens**
1. **Landing page** — positioning + confidentiality promise front and center ("Never sold. Never shared. Used only to help you."), simple "Start a conversation" CTA.
2. **Onboarding (2–3 steps)** — what this is / isn't (coach, not therapist), the no-sale/no-share commitment + retention policy consent, optional context (relationship type, what's on their mind).
3. **Chat screen** — main interface:
   - Left: conversation history (titled, e.g. auto-summarized "Conflict about in-laws")
   - Center: chat thread, streaming responses, confidentiality badge in header
   - Bottom: composer with a subtle "this conversation is private" microcopy
4. **Settings** — data export, delete my data, delete account, retention policy detail.
5. **Crisis resource panel** — surfaces automatically when a safety flag triggers, otherwise hidden.

**Tone/design direction**
- Warm, calm, non-clinical — avoid anything that looks like a corporate SaaS dashboard. Soft colors, generous whitespace, conversational typography.
- Avoid gamification (streaks, badges) — this isn't a habit app, it's a sensitive space.

---

## 8. Suggested Repo Structure

```
/app
  /(marketing)/page.tsx          -- landing page
  /chat/page.tsx                 -- main chat UI
  /settings/page.tsx
  /api/chat/route.ts             -- streams from Claude, writes encrypted messages
  /api/export/route.ts
  /api/delete/route.ts
/lib
  /claude.ts                     -- Claude API client, system prompt
  /encryption.ts                 -- envelope encryption helpers
  /safety.ts                     -- safety classifier + escalation logic
  /db.ts
/prisma (or /db/schema.sql)
/components
  /Chat/
  /Onboarding/
  /Settings/
SPEC.md                          -- this document, for Claude Code to reference
```

---

## 9. MVP Roadmap

1. **Week 1** — Auth, DB schema, basic chat UI, Claude API streaming (no encryption yet, local dev only).
2. **Week 2** — Field-level encryption, retention/auto-purge job, confidentiality UI elements.
3. **Week 3** — Safety/escalation layer, crisis resource panel, export/delete flows.
4. **Week 4** — Legal review of retention policy and ToS, polish UI, soft launch to a small user group.

---

*Next step: drop this file into your repo as `SPEC.md` and have Claude Code or Google Antigravity 2.0 scaffold Hushlee's Next.js project from Section 8's structure.*
