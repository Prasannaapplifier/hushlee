import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const RETENTION_DAYS = 90;

async function runAutoPurge() {
  const startTime = Date.now();
  console.log(`\n======================================================`);
  console.log(`[Hushlee Compliance Auto-Purge Job]`);
  console.log(`Started at: ${new Date().toISOString()}`);
  console.log(`Retention window: ${RETENTION_DAYS} days`);

  const cutoffDate = new Date(Date.now() - RETENTION_DAYS * 24 * 60 * 60 * 1000);
  console.log(`Cutoff date for permanent deletion: ${cutoffDate.toISOString()}`);
  console.log(`======================================================\n`);

  try {
    // 1. Purge messages older than 90 days
    const deletedMessages = await prisma.message.deleteMany({
      where: {
        createdAt: {
          lt: cutoffDate,
        },
      },
    });
    console.log(`✓ Deleted ${deletedMessages.count} messages older than 90 days.`);

    // 2. Purge conversations older than 90 days or empty
    const deletedConversations = await prisma.conversation.deleteMany({
      where: {
        createdAt: {
          lt: cutoffDate,
        },
      },
    });
    console.log(`✓ Deleted ${deletedConversations.count} conversations older than 90 days.`);

    // 3. Purge expired Auth.js sessions and verification tokens
    const deletedSessions = await prisma.session.deleteMany({
      where: {
        expires: {
          lt: new Date(),
        },
      },
    });
    console.log(`✓ Cleared ${deletedSessions.count} expired auth sessions.`);

    // 4. Log compliance purge event to audit_log
    await prisma.auditLog.create({
      data: {
        actor: 'system',
        action: 'deletion_requested',
        metadata: {
          type: 'retention_policy_auto_purge',
          retentionWindowDays: RETENTION_DAYS,
          cutoffDate: cutoffDate.toISOString(),
          purgedMessagesCount: deletedMessages.count,
          purgedConversationsCount: deletedConversations.count,
          purgedSessionsCount: deletedSessions.count,
          executedAt: new Date().toISOString(),
          durationMs: Date.now() - startTime,
        },
      },
    });
    console.log(`✓ Compliance record logged to audit_log table with actor 'system'.`);

    console.log(`\nAuto-purge completed successfully in ${Date.now() - startTime}ms.\n`);
  } catch (err) {
    console.error(`✗ Auto-purge failed with error:`, err);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

runAutoPurge();
