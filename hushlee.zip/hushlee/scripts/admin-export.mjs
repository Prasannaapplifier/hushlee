import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';

const prisma = new PrismaClient();
const ALGORITHM = 'aes-256-gcm';

function getMasterKey() {
  const masterKeyHex = process.env.ENCRYPTION_MASTER_KEY;
  if (!masterKeyHex) {
    return crypto.scryptSync('hushlee-default-dev-master-key-32b', 'salt-2026', 32);
  }
  return Buffer.from(masterKeyHex, 'hex');
}

function decryptWithKey(payload, key) {
  const iv = Buffer.from(payload.iv, 'base64');
  const authTag = Buffer.from(payload.authTag, 'base64');
  const ciphertext = Buffer.from(payload.ciphertext, 'base64');

  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

async function runAdminAccess() {
  const args = process.argv.slice(2);
  const userIdentifier = args[0];
  const reasonArg = args.find(a => a.startsWith('--reason='))?.replace('--reason=', '');
  const adminArg = args.find(a => a.startsWith('--admin='))?.replace('--admin=', '') || 'admin-system';

  console.log(`\n======================================================`);
  console.log(`[Hushlee Privileged Admin Access & Audit Tool]`);
  console.log(`======================================================\n`);

  if (!userIdentifier || !reasonArg || reasonArg.trim().length < 10) {
    console.error('ERROR: Privileged access requires a target user and a justified reason.');
    console.error('Usage: node scripts/admin-export.mjs <userId_or_email> --reason="Justification reason (min 10 chars)" [--admin="admin_id"]\n');
    process.exit(1);
  }

  // 1. Locate User
  const user = await prisma.user.findFirst({
    where: {
      OR: [
        { id: userIdentifier },
        { email: userIdentifier },
      ],
    },
    include: {
      conversations: {
        include: {
          messages: {
            orderBy: { createdAt: 'asc' },
          },
        },
      },
    },
  });

  if (!user) {
    console.error(`User not found: ${userIdentifier}`);
    process.exit(1);
  }

  // 2. Mandatory Audit Log entry BEFORE decryption
  console.log(`Target User: ${user.id} (${user.email || 'Guest/Anonymous'})`);
  console.log(`Admin Actor: ${adminArg}`);
  console.log(`Justification: "${reasonArg}"`);
  console.log(`\nLogging privileged access to audit_log table...`);

  await prisma.auditLog.create({
    data: {
      userId: user.id,
      actor: 'admin',
      action: 'admin_access',
      metadata: {
        adminId: adminArg,
        reason: reasonArg,
        targetUserId: user.id,
        conversationsCount: user.conversations.length,
        timestamp: new Date().toISOString(),
      },
    },
  });
  console.log(`✓ Audit log entry committed. (action: 'admin_access', actor: 'admin')`);

  // 3. Unpack User DEK using Master KEK
  if (!user.encryptedDek) {
    console.error(`User has no encrypted DEK recorded.`);
    process.exit(1);
  }

  const masterKey = getMasterKey();
  const dekPayload = JSON.parse(user.encryptedDek);
  const userDek = decryptWithKey(dekPayload, masterKey);

  // 4. Decrypt and display conversations
  console.log(`\nDecrypted User Conversations (${user.conversations.length} total):`);
  console.log(`------------------------------------------------------`);

  for (const conv of user.conversations) {
    console.log(`\nConversation: "${conv.title}" (ID: ${conv.id}, Created: ${conv.createdAt.toISOString()})`);
    for (const msg of conv.messages) {
      let plaintext = '';
      try {
        const msgPayload = JSON.parse(msg.contentEncrypted);
        plaintext = decryptWithKey(msgPayload, userDek).toString('utf8');
      } catch (err) {
        plaintext = `[Decryption error: ${err.message}]`;
      }
      console.log(`  [${msg.role.toUpperCase()}] ${plaintext}`);
    }
  }

  console.log(`\n------------------------------------------------------`);
  console.log(`Admin access complete. Decryption logged in compliance records.\n`);
}

runAdminAccess()
  .catch(err => {
    console.error('Admin access failed:', err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
