import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const BASE_URL = 'http://localhost:3000';

async function runE2ETest() {
  console.log('========================================================');
  console.log('   HUSHLEE END-TO-END FLOW & DATABASE VALIDATION       ');
  console.log('========================================================\n');

  let cookieHeader = '';

  // 1. Initial User Status (Establishes session in PostgreSQL)
  console.log('1. Testing User Status Endpoint (/api/user/status)...');
  const res1 = await fetch(`${BASE_URL}/api/user/status`);
  const setCookie = res1.headers.get('set-cookie');
  if (setCookie) {
    cookieHeader = setCookie.split(';')[0];
  }
  const status1 = await res1.json();
  console.log(`   User ID established: ${status1.id}`);
  console.log(`   Initial Consent Status: ${status1.hasConsented} (Expected: false)`);
  if (status1.hasConsented !== false) {
    throw new Error('Initial consent should be false before onboarding');
  }

  // 2. Submit Onboarding Consent (Records consent_backup_ack_at & initializes DEK)
  console.log('\n2. Submitting Onboarding Consent (/api/onboarding/consent)...');
  const res2 = await fetch(`${BASE_URL}/api/onboarding/consent`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Cookie: cookieHeader,
    },
    body: JSON.stringify({
      consentGiven: true,
      relationshipType: 'romantic',
      initialContext: 'Navigating disagreements about shared quality time vs work.',
    }),
  });
  const consentResult = await res2.json();
  console.log(`   Consent recorded successfully:`, consentResult.success);
  console.log(`   Consent Timestamp: ${consentResult.consentBackupAckAt}`);

  // 3. Verify User Status now has consent
  console.log('\n3. Verifying Updated User Status...');
  const res3 = await fetch(`${BASE_URL}/api/user/status`, {
    headers: { Cookie: cookieHeader },
  });
  const status2 = await res3.json();
  console.log(`   Updated Consent Status: ${status2.hasConsented} (Expected: true)`);
  if (!status2.hasConsented) throw new Error('User consent was not properly recorded');

  // 4. Send Normal Chat Reflection
  console.log('\n4. Sending Normal Relationship Reflection (/api/chat)...');
  const reflectionText = 'My partner and I have been arguing frequently about balancing personal time with shared goals.';
  const res4 = await fetch(`${BASE_URL}/api/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Cookie: cookieHeader,
    },
    body: JSON.stringify({
      message: reflectionText,
    }),
  });

  const convId = res4.headers.get('x-conversation-id');
  const safetyFlagged1 = res4.headers.get('x-safety-flagged');
  const reader1 = res4.body.getReader();
  const decoder = new TextDecoder();
  let coachReply1 = '';
  while (true) {
    const { done, value } = await reader1.read();
    if (done) break;
    coachReply1 += decoder.decode(value);
  }

  console.log(`   Conversation ID created: ${convId}`);
  console.log(`   Safety Flagged: ${safetyFlagged1} (Expected: false)`);
  console.log(`   Coach Streamed Response Preview:\n   "${coachReply1.slice(0, 140).replace(/\n/g, ' ')}..."`);

  // 5. Send Safety Escalation / Crisis Message
  console.log('\n5. Testing Safety Escalation Trigger (/api/chat)...');
  const crisisText = 'I am completely overwhelmed and feeling hopeless. I just want to kill myself.';
  const res5 = await fetch(`${BASE_URL}/api/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Cookie: cookieHeader,
    },
    body: JSON.stringify({
      conversationId: convId,
      message: crisisText,
    }),
  });

  const safetyFlagged2 = res5.headers.get('x-safety-flagged');
  const safetyCategory2 = res5.headers.get('x-safety-category');
  const reader2 = res5.body.getReader();
  let coachReply2 = '';
  while (true) {
    const { done, value } = await reader2.read();
    if (done) break;
    coachReply2 += decoder.decode(value);
  }

  console.log(`   Safety Flagged: ${safetyFlagged2} (Expected: true)`);
  console.log(`   Detected Safety Category: ${safetyCategory2} (Expected: self_harm)`);
  console.log(`   De-escalation Response Preview:\n   "${coachReply2.slice(0, 140).replace(/\n/g, ' ')}..."`);

  // 6. Test Data Export (GDPR/DPDP Decryption)
  console.log('\n6. Testing Data Export (/api/export)...');
  const res6 = await fetch(`${BASE_URL}/api/export`, {
    headers: { Cookie: cookieHeader },
  });
  const exportData = await res6.json();
  console.log(`   Export received. Conversations in export: ${exportData.conversations.length}`);
  console.log(`   Total messages decrypted: ${exportData.conversations[0]?.messages.length}`);
  console.log(`   First Decrypted Message: "${exportData.conversations[0]?.messages[0]?.content}"`);

  // 7. Verify Database Contents Directly in PostgreSQL
  console.log('\n7. Verifying PostgreSQL State via Prisma...');
  const dbUser = await prisma.user.findUnique({
    where: { id: status1.id },
    include: {
      conversations: {
        include: {
          messages: {
            include: { safetyFlags: true },
          },
        },
      },
      auditLogs: true,
    },
  });

  console.log(`   User in PostgreSQL: Found (ID: ${dbUser.id})`);
  console.log(`   Has encrypted DEK in PostgreSQL: ${Boolean(dbUser.encryptedDek)}`);
  console.log(`   DEK ciphertext sample: ${dbUser.encryptedDek?.slice(0, 45)}...`);
  console.log(`   Consent timestamp in PostgreSQL: ${dbUser.consentBackupAckAt?.toISOString()}`);

  const rawFirstMsg = dbUser.conversations[0].messages[0];
  console.log(`   Message 1 Role: ${rawFirstMsg.role}`);
  console.log(`   Message 1 Encrypted Content in PostgreSQL (Raw):`);
  console.log(`     ${rawFirstMsg.contentEncrypted.slice(0, 75)}...`);

  // Verify that raw database content is encrypted and NOT plaintext
  if (rawFirstMsg.contentEncrypted.includes(reflectionText)) {
    throw new Error('SECURITY VIOLATION: Raw message plaintext was found in PostgreSQL!');
  } else {
    console.log(`   ✓ VERIFIED: Raw database content is ciphertext, plaintext NEVER stored!`);
  }

  // Verify safety_flags in DB
  const flaggedDbMsg = dbUser.conversations[0].messages.find(m => m.safetyFlags.length > 0);
  console.log(`   ✓ VERIFIED: safety_flags in PostgreSQL:`);
  console.log(`     Category: ${flaggedDbMsg.safetyFlags[0].category}`);
  console.log(`     Severity: ${flaggedDbMsg.safetyFlags[0].severity}`);

  // Verify audit_log in DB
  console.log(`   ✓ VERIFIED: audit_log entries in PostgreSQL:`);
  for (const log of dbUser.auditLogs) {
    console.log(`     - [${log.actor}] ${log.action} at ${log.createdAt.toISOString()}`);
  }

  console.log('\n========================================================');
  console.log('   ALL END-TO-END VALIDATION TESTS PASSED 100%!        ');
  console.log('========================================================\n');
}

runE2ETest()
  .catch(err => {
    console.error('E2E Test Failed:', err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
