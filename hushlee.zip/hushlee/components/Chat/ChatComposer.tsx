'use client';

import { useState, useRef, useEffect } from 'react';
import { ArrowUp, Lock } from 'lucide-react';

interface ChatComposerProps {
  onSend: (message: string) => void;
  disabled?: boolean;
}

export function ChatComposer({ onSend, disabled }: ChatComposerProps) {
  const [text, setText] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
    }
  }, [text]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!text.trim() || disabled) return;
    onSend(text.trim());
    setText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 sm:px-6 pb-4">
      <form
        onSubmit={handleSubmit}
        className="relative flex items-end bg-white border border-[#E0D7CC] rounded-3xl p-2 shadow-xs focus-within:ring-2 focus-within:ring-[#5D7052]/20 focus-within:border-[#5D7052] transition-all"
      >
        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Share what is on your mind... (Enter to send, Shift+Enter for new line)"
          disabled={disabled}
          rows={1}
          className="flex-1 max-h-40 resize-none bg-transparent px-3 py-2 text-sm text-[#2C3333] placeholder-[#A0AAA5] focus:outline-none"
        />

        <button
          type="submit"
          disabled={!text.trim() || disabled}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition-all shrink-0 mb-0.5 ${
            text.trim() && !disabled
              ? 'bg-[#5D7052] text-white hover:bg-[#4D5E44] shadow-xs'
              : 'bg-[#EAE4D7] text-[#9FA8A4] cursor-not-allowed'
          }`}
          aria-label="Send message"
        >
          <ArrowUp className="w-4 h-4" />
        </button>
      </form>

      {/* Persistent confidentiality microcopy */}
      <div className="flex items-center justify-center gap-1.5 text-[11px] text-[#8F9A95] mt-2.5">
        <Lock className="w-3 h-3 text-[#5D7052]" />
        <span>This conversation is private & field-encrypted at rest</span>
      </div>
    </div>
  );
}
