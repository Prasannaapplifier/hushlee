'use client';

import Link from 'next/link';
import { MessageSquarePlus, Settings, Trash2, ShieldCheck, X, BarChart3 } from 'lucide-react';

export interface ConversationItem {
  id: string;
  title: string;
  createdAt: string;
}

interface ChatSidebarProps {
  conversations: ConversationItem[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export function ChatSidebar({
  conversations,
  activeId,
  onSelect,
  onNew,
  onDelete,
  isOpenMobile,
  onCloseMobile,
}: ChatSidebarProps) {
  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 bg-black/30 z-30 md:hidden backdrop-blur-2xs"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 w-72 bg-[#F7F4EE] border-r border-[#EAE3D9] flex flex-col justify-between p-4 transition-transform duration-200 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div>
          {/* Header */}
          <div className="flex items-center justify-between mb-5">
            <Link href="/" className="flex items-center gap-2.5">
              <span className="w-7 h-7 rounded-full bg-[#5D7052] flex items-center justify-center text-white font-medium text-xs">
                H
              </span>
              <span className="font-serif text-xl tracking-tight text-[#1F2421]">Hushlee</span>
            </Link>

            <button
              onClick={onCloseMobile}
              className="md:hidden text-[#8F9A95] hover:text-[#1F2421] p-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* New reflection button */}
          <button
            onClick={() => {
              onNew();
              onCloseMobile();
            }}
            className="w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl bg-white border border-[#DFD8CC] text-[#2C3333] text-xs font-medium hover:bg-[#F0ECE1] transition-all shadow-2xs mb-5"
          >
            <MessageSquarePlus className="w-4 h-4 text-[#5D7052]" />
            <span>New Reflection</span>
          </button>

          {/* Conversation List */}
          <div className="space-y-1 overflow-y-auto max-h-[calc(100vh-280px)] pr-1">
            <div className="text-[11px] font-medium text-[#8F9A95] uppercase tracking-wider px-2 py-1">
              Conversations
            </div>

            {conversations.length === 0 ? (
              <div className="text-xs text-[#9DA7A2] px-2 py-4 italic">
                No conversations yet. Start a new one above.
              </div>
            ) : (
              conversations.map((conv) => {
                const isActive = conv.id === activeId;
                return (
                  <div
                    key={conv.id}
                    className={`group flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium cursor-pointer transition-colors ${
                      isActive
                        ? 'bg-[#EFECE6] text-[#1F2421]'
                        : 'text-[#5A6460] hover:bg-[#F2EFE8] hover:text-[#1F2421]'
                    }`}
                    onClick={() => {
                      onSelect(conv.id);
                      onCloseMobile();
                    }}
                  >
                    <span className="truncate pr-2">{conv.title}</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete(conv.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 hover:text-red-600 transition-opacity p-1"
                      title="Delete conversation"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Bottom links */}
        <div className="pt-4 border-t border-[#EAE3D9] space-y-2">
          <div className="flex items-center gap-2 px-2 py-1 text-[11px] text-[#7B8580]">
            <ShieldCheck className="w-3.5 h-3.5 text-[#5D7052]" />
            <span>90-Day Auto-Purge Active</span>
          </div>

          <Link
            href="/settings"
            className="flex items-center gap-2 px-2 py-2 rounded-xl text-xs font-medium text-[#5A6460] hover:bg-[#EFECE6] hover:text-[#1F2421] transition-colors"
          >
            <Settings className="w-4 h-4" />
            <span>Settings & Data Rights</span>
          </Link>

          <Link
            href="/admin"
            className="flex items-center gap-2 px-2 py-2 rounded-xl text-xs font-medium text-[#5D7052] bg-[#5D7052]/10 hover:bg-[#5D7052]/20 transition-colors"
          >
            <BarChart3 className="w-4 h-4 text-[#5D7052]" />
            <span>Admin & Compliance</span>
          </Link>
        </div>
      </aside>
    </>
  );
}
