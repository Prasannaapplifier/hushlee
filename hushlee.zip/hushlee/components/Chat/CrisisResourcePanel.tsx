'use client';

import { useState } from 'react';
import { HeartHandshake, Phone, MessageSquare, Globe, ChevronUp, ChevronDown, ShieldAlert } from 'lucide-react';

interface CrisisResourcePanelProps {
  isOpen: boolean;
  category?: 'self_harm' | 'abuse_disclosure' | 'crisis' | null;
  onDismiss?: () => void;
}

export function CrisisResourcePanel({ isOpen, category, onDismiss }: CrisisResourcePanelProps) {
  const [collapsed, setCollapsed] = useState(false);

  if (!isOpen) return null;

  const isAbuse = category === 'abuse_disclosure';

  return (
    <div className="w-full max-w-3xl mx-auto px-4 sm:px-6 pt-3 pb-2 transition-all">
      <div className="bg-[#FAF3EB] border border-[#E8D7C7] rounded-3xl p-5 sm:p-6 shadow-sm text-[#2C3333] relative overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#E58276]/20 flex items-center justify-center text-[#B84E42]">
              <HeartHandshake className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif text-base sm:text-lg font-medium text-[#1F2421]">
                {isAbuse ? 'Safe Support & Confidential Resources' : 'Immediate Support is Available'}
              </h3>
              <p className="text-xs text-[#7B8580]">
                You deserve care and safety. These confidential resources are free and available 24/7.
              </p>
            </div>
          </div>

          <button
            onClick={() => setCollapsed(!collapsed)}
            className="text-[#8F9A95] hover:text-[#1F2421] p-1.5 rounded-lg hover:bg-[#F2E7DC] transition-colors"
            title={collapsed ? 'Expand resources' : 'Collapse panel'}
          >
            {collapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>

        {/* Expandable Resource Cards */}
        {!collapsed && (
          <div className="mt-4 space-y-3">
            {isAbuse ? (
              // Domestic violence & abuse resources
              <div className="p-3.5 bg-white/90 rounded-2xl border border-[#E4D2C0] text-xs">
                <div className="flex items-center gap-2 font-medium text-[#1F2421] mb-1">
                  <ShieldAlert className="w-4 h-4 text-[#B84E42]" />
                  <span>National Domestic Violence Hotline</span>
                </div>
                <p className="text-[#5A6460] mb-2 leading-relaxed">
                  Confidential, non-judgmental support, safety planning, and local resources.
                </p>
                <div className="flex flex-wrap gap-2 text-[11px]">
                  <a
                    href="tel:18007997233"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#B84E42] text-white font-medium hover:bg-[#9E3E34] transition-colors"
                  >
                    <Phone className="w-3 h-3" />
                    <span>Call 1-800-799-SAFE (7233)</span>
                  </a>
                  <a
                    href="sms:88788?body=START"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#EAE2D7] text-[#424A45] font-medium hover:bg-[#E0D7CB] transition-colors"
                  >
                    <MessageSquare className="w-3 h-3" />
                    <span>Text &quot;START&quot; to 88788</span>
                  </a>
                  <a
                    href="https://www.thehotline.org"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-[#DDD3C7] text-[#5A6460] hover:text-[#1F2421] transition-colors"
                  >
                    <Globe className="w-3 h-3" />
                    <span>thehotline.org</span>
                  </a>
                </div>
              </div>
            ) : (
              // Self-harm / Crisis resources
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="p-3.5 bg-white/90 rounded-2xl border border-[#E4D2C0] text-xs">
                  <div className="flex items-center gap-2 font-medium text-[#1F2421] mb-1">
                    <Phone className="w-3.5 h-3.5 text-[#5D7052]" />
                    <span>988 Suicide &amp; Crisis Lifeline</span>
                  </div>
                  <p className="text-[#5A6460] mb-2.5 text-[11px] leading-relaxed">
                    Free, confidential 24/7 call and text service for anyone in emotional distress.
                  </p>
                  <a
                    href="tel:988"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#5D7052] text-white text-[11px] font-medium hover:bg-[#4D5E44] transition-colors"
                  >
                    <Phone className="w-3 h-3" />
                    <span>Call or Text 988</span>
                  </a>
                </div>

                <div className="p-3.5 bg-white/90 rounded-2xl border border-[#E4D2C0] text-xs">
                  <div className="flex items-center gap-2 font-medium text-[#1F2421] mb-1">
                    <MessageSquare className="w-3.5 h-3.5 text-[#5D7052]" />
                    <span>Crisis Text Line</span>
                  </div>
                  <p className="text-[#5A6460] mb-2.5 text-[11px] leading-relaxed">
                    Connect with a trained volunteer crisis counselor 24 hours a day, 7 days a week.
                  </p>
                  <a
                    href="sms:741741?body=HOME"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#EAE2D7] text-[#424A45] text-[11px] font-medium hover:bg-[#E0D7CB] transition-colors"
                  >
                    <MessageSquare className="w-3 h-3" />
                    <span>Text &quot;HOME&quot; to 741741</span>
                  </a>
                </div>
              </div>
            )}

            {/* International link */}
            <div className="flex items-center justify-between pt-2 border-t border-[#E8D7C7]/60 text-[11px] text-[#7B8580]">
              <span className="flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-[#8F9A95]" />
                <span>Outside the US / Canada?</span>
              </span>
              <a
                href="https://findahelpline.com"
                target="_blank"
                rel="noopener noreferrer"
                className="underline hover:text-[#1F2421] transition-colors"
              >
                Find international helplines in 130+ countries
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
