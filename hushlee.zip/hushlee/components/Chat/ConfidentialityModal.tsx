'use client';

import { X, Lock, ShieldCheck, Clock, FileKey2 } from 'lucide-react';

interface ConfidentialityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ConfidentialityModal({ isOpen, onClose }: ConfidentialityModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
      <div className="bg-[#FAF8F5] border border-[#E8E1D7] rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl text-[#2C3333] relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-[#8F9A95] hover:text-[#1F2421] transition-colors p-1"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-2xl bg-[#EFECE6] flex items-center justify-center text-[#5D7052]">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-serif text-xl text-[#1F2421]">Confidentiality Guarantee</h2>
            <p className="text-xs text-[#7B8580]">How your privacy is architected</p>
          </div>
        </div>

        <div className="space-y-4 text-xs text-[#4A5548] leading-relaxed">
          <div className="p-3.5 bg-white rounded-2xl border border-[#EAE3D9]">
            <div className="flex items-center gap-2 font-medium text-[#1F2421] mb-1">
              <ShieldCheck className="w-4 h-4 text-[#5D7052]" />
              <span>We Never Sell or Broker Your Data</span>
            </div>
            <p>
              Your personal conversations are never sold to advertisers, data aggregators, or brokers. We do not use third-party analytics trackers that pipe chat content to external marketing clouds.
            </p>
          </div>

          <div className="p-3.5 bg-white rounded-2xl border border-[#EAE3D9]">
            <div className="flex items-center gap-2 font-medium text-[#1F2421] mb-1">
              <FileKey2 className="w-4 h-4 text-[#5D7052]" />
              <span>Field-Level Envelope Encryption</span>
            </div>
            <p>
              Each message is encrypted before it is written to the database using an envelope encryption scheme (per-user DEK + master KEK). Raw messages cannot be read by database administrators without a logged audit trail.
            </p>
          </div>

          <div className="p-3.5 bg-white rounded-2xl border border-[#EAE3D9]">
            <div className="flex items-center gap-2 font-medium text-[#1F2421] mb-1">
              <Clock className="w-4 h-4 text-[#5D7052]" />
              <span>90-Day Auto-Purge Policy</span>
            </div>
            <p>
              Conversations are retained for only 90 days, after which they are permanently destroyed by an automated background purge. You can also export or erase your data at any time from Settings.
            </p>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-[#EAE3D9] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-full bg-[#5D7052] text-white text-xs font-medium hover:bg-[#4D5E44] transition-colors"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
}
