'use client';

import { ShieldCheck } from 'lucide-react';

export interface MessageProps {
  id?: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  isStreaming?: boolean;
  createdAt?: string | Date;
}

export function ChatMessage({ role, content, isStreaming, createdAt }: MessageProps) {
  const isAssistant = role === 'assistant';

  return (
    <div
      className={`py-4 sm:py-6 flex gap-4 w-full ${
        isAssistant ? 'justify-start' : 'justify-end'
      }`}
    >
      {/* Assistant Avatar */}
      {isAssistant && (
        <div className="w-8 h-8 rounded-full bg-[#5D7052] flex items-center justify-center text-white font-medium text-xs shrink-0 shadow-2xs mt-0.5">
          H
        </div>
      )}

      {/* Message Bubble */}
      <div
        className={`max-w-[85%] sm:max-w-2xl px-5 py-4 rounded-3xl leading-relaxed text-sm ${
          isAssistant
            ? 'bg-white/90 border border-[#E8E1D7] text-[#2C3333] shadow-2xs'
            : 'bg-[#5D7052] text-white shadow-xs rounded-tr-sm'
        }`}
      >
        <div className="whitespace-pre-wrap font-normal">
          {content}
          {isStreaming && (
            <span className="inline-block w-1.5 h-4 ml-1 bg-[#5D7052] animate-pulse align-middle" />
          )}
        </div>

        {/* Message metadata */}
        <div
          className={`flex items-center gap-2 mt-2 text-[10px] ${
            isAssistant ? 'text-[#9DA7A2]' : 'text-white/70 justify-end'
          }`}
        >
          {isAssistant && (
            <div className="flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-[#5D7052]" />
              <span>Confidential Coach</span>
            </div>
          )}
          {createdAt && (
            <span>
              {new Date(createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
