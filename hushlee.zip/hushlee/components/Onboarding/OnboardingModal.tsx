'use client';

import { useState } from 'react';
import { ShieldCheck, Lock, Heart, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';

interface OnboardingModalProps {
  isOpen: boolean;
  onComplete: (data: { relationshipType: string; initialContext: string }) => void;
  userEmail?: string;
}

export function OnboardingModal({ isOpen, onComplete, userEmail }: OnboardingModalProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [hasConsented, setHasConsented] = useState(false);
  const [relationshipType, setRelationshipType] = useState<string>('romantic');
  const [initialContext, setInitialContext] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleConsentSubmit = async () => {
    if (!hasConsented) {
      setError('You must accept the retention policy to proceed.');
      return;
    }
    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/onboarding/consent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          consentGiven: true,
          relationshipType,
          initialContext,
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to record consent. Please try again.');
      }

      setStep(3);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error recording consent';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleFinish = () => {
    onComplete({ relationshipType, initialContext });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm transition-opacity">
      <div className="bg-[#FAF8F5] border border-[#E8E1D7] rounded-3xl max-w-xl w-full p-8 shadow-2xl text-[#2C3333] relative overflow-hidden">
        {/* Step Progress indicator */}
        <div className="flex items-center justify-between mb-8 pb-4 border-b border-[#EAE3D9]">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-full bg-[#5D7052] flex items-center justify-center text-white font-medium text-xs">
              H
            </span>
            <span className="font-serif text-lg tracking-tight text-[#1F2421]">Welcome to Hushlee</span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-[#7B8580] font-medium">
            <span className={`w-6 h-6 rounded-full flex items-center justify-center ${step === 1 ? 'bg-[#5D7052] text-white' : 'bg-[#EAE3D9] text-[#5A6460]'}`}>1</span>
            <span className="text-[#CCC]">―</span>
            <span className={`w-6 h-6 rounded-full flex items-center justify-center ${step === 2 ? 'bg-[#5D7052] text-white' : 'bg-[#EAE3D9] text-[#5A6460]'}`}>2</span>
            <span className="text-[#CCC]">―</span>
            <span className={`w-6 h-6 rounded-full flex items-center justify-center ${step === 3 ? 'bg-[#5D7052] text-white' : 'bg-[#EAE3D9] text-[#5A6460]'}`}>3</span>
          </div>
        </div>

        {/* STEP 1: Coach vs. Therapist Framing */}
        {step === 1 && (
          <div className="space-y-6">
            <div className="w-12 h-12 rounded-2xl bg-[#EFECE6] flex items-center justify-center text-[#5D7052]">
              <Heart className="w-6 h-6" />
            </div>

            <div>
              <h2 className="font-serif text-2xl text-[#1F2421] mb-2">
                A Coach, Not a Licensed Therapist
              </h2>
              <p className="text-[#5A6460] text-sm leading-relaxed">
                Before we begin, it is important to clarify how Hushlee works so you know what to expect:
              </p>
            </div>

            <div className="space-y-3 bg-white/70 p-4 rounded-2xl border border-[#EAE3D9] text-xs text-[#4A5548] leading-relaxed">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#5D7052] shrink-0 mt-0.5" />
                <span>
                  <strong>What Hushlee is:</strong> An empathetic, AI-guided sounding board designed to help you reflect on relationships, clarify communication, and practice healthy boundary-setting.
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-[#C1665D] shrink-0 mt-0.5" />
                <span>
                  <strong>What Hushlee is NOT:</strong> A licensed therapist, psychiatrist, medical service, or emergency crisis hotline. It cannot diagnose or provide clinical mental health treatment.
                </span>
              </div>
            </div>

            <button
              onClick={() => setStep(2)}
              className="w-full py-3.5 rounded-full bg-[#5D7052] text-white font-medium text-sm hover:bg-[#4D5E44] transition-colors flex items-center justify-center gap-2 shadow-sm"
            >
              <span>I Understand — Continue</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* STEP 2: Confidentiality & 90-Day Retention Consent */}
        {step === 2 && (
          <div className="space-y-6">
            <div className="w-12 h-12 rounded-2xl bg-[#EFECE6] flex items-center justify-center text-[#5D7052]">
              <Lock className="w-6 h-6" />
            </div>

            <div>
              <h2 className="font-serif text-2xl text-[#1F2421] mb-2">
                Our Confidentiality Commitment
              </h2>
              <p className="text-[#5A6460] text-sm leading-relaxed">
                What you share stays between you and your AI coach.
              </p>
            </div>

            <div className="space-y-2.5 text-xs text-[#4A5548]">
              <div className="p-3 bg-white/80 rounded-xl border border-[#EAE3D9]">
                <strong className="text-[#1F2421] block mb-1">🚫 Never Sold. Never Shared.</strong>
                We never sell your data to advertisers, data brokers, or third parties. It is never used for marketing or commercial model training.
              </div>
              <div className="p-3 bg-white/80 rounded-xl border border-[#EAE3D9]">
                <strong className="text-[#1F2421] block mb-1">🔐 Field-Level Envelope Encryption</strong>
                Your messages are encrypted at rest with unique cryptographic keys. Even internal database administrators cannot view plaintext messages.
              </div>
              <div className="p-3 bg-white/80 rounded-xl border border-[#EAE3D9]">
                <strong className="text-[#1F2421] block mb-1">⏳ 90-Day Auto-Purge Policy</strong>
                Conversations are automatically destroyed 90 days after creation. You also have instant self-service data export and deletion rights anytime.
              </div>
            </div>

            {error && (
              <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs border border-red-200">
                {error}
              </div>
            )}

            {/* Mandatory Explicit Consent Checkbox */}
            <label className="flex items-start gap-3 p-3.5 rounded-xl bg-[#F0ECE1] border border-[#DDD7CD] cursor-pointer hover:bg-[#EAE4D7] transition-colors">
              <input
                type="checkbox"
                checked={hasConsented}
                onChange={(e) => setHasConsented(e.target.checked)}
                className="mt-0.5 w-4 h-4 rounded text-[#5D7052] focus:ring-[#5D7052]"
              />
              <span className="text-xs text-[#2C3333] leading-relaxed font-medium">
                I explicitly consent to Hushlee&apos;s 90-day retention and auto-purge policy, and acknowledge the no-sale / no-share confidentiality guarantee.
              </span>
            </label>

            <button
              onClick={handleConsentSubmit}
              disabled={!hasConsented || loading}
              className={`w-full py-3.5 rounded-full font-medium text-sm transition-all flex items-center justify-center gap-2 shadow-sm ${
                hasConsented && !loading
                  ? 'bg-[#5D7052] text-white hover:bg-[#4D5E44]'
                  : 'bg-[#DDD7CD] text-[#8F9A95] cursor-not-allowed'
              }`}
            >
              <span>{loading ? 'Recording Consent...' : 'Accept & Continue'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* STEP 3: Optional Context */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="w-12 h-12 rounded-2xl bg-[#EFECE6] flex items-center justify-center text-[#5D7052]">
              <ShieldCheck className="w-6 h-6" />
            </div>

            <div>
              <h2 className="font-serif text-2xl text-[#1F2421] mb-2">
                What relationship are you navigating?
              </h2>
              <p className="text-[#5A6460] text-sm leading-relaxed">
                This helps your coach tailor communication frameworks and perspective-taking.
              </p>
            </div>

            {/* Relationship category selector */}
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { id: 'romantic', label: 'Romantic / Partner' },
                { id: 'family', label: 'Family Dynamics' },
                { id: 'friendship', label: 'Friendship' },
                { id: 'workplace', label: 'Workplace / Team' },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setRelationshipType(item.id)}
                  className={`p-3 rounded-xl text-xs font-medium text-left border transition-all ${
                    relationshipType === item.id
                      ? 'bg-[#5D7052] text-white border-[#5D7052] shadow-2xs'
                      : 'bg-white/80 text-[#3E4A44] border-[#E8E1D7] hover:bg-[#F2EEE7]'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Optional initial thought */}
            <div>
              <label className="block text-xs font-medium text-[#4A5548] mb-1.5">
                What is on your mind today? (Optional)
              </label>
              <textarea
                value={initialContext}
                onChange={(e) => setInitialContext(e.target.value)}
                placeholder="e.g., We had an argument about priorities, or I am feeling unappreciated..."
                rows={3}
                className="w-full text-xs p-3 rounded-xl bg-white border border-[#E0D7CC] text-[#2C3333] placeholder-[#A0AAA5] focus:outline-none focus:ring-1 focus:ring-[#5D7052]"
              />
            </div>

            <button
              onClick={handleFinish}
              className="w-full py-3.5 rounded-full bg-[#5D7052] text-white font-medium text-sm hover:bg-[#4D5E44] transition-colors flex items-center justify-center gap-2 shadow-sm"
            >
              <span>Begin Confidential Session</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
